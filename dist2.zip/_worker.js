export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/api')) {
      const vpsUrl = 'http://98.142.245.190.nip.io' + url.pathname;
      const newRequest = new Request(vpsUrl, request);
      return await fetch(newRequest);
    }
    return env.ASSETS.fetch(request);
  }
};
