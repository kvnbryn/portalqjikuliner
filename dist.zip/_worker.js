export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    
    // Kalau request ke /api, lempar ke VPS
    if (url.pathname.startsWith('/api')) {
      const vpsUrl = 'http://98.142.245.190' + url.pathname;
      const newRequest = new Request(vpsUrl, request);
      return await fetch(newRequest);
    }
    
    // Kalau bukan, biarin Cloudflare nampilin file website (React)
    return env.ASSETS.fetch(request);
  }
};
